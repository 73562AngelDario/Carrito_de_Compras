// database.js - Puente de conexión entre la Tienda y el Administrador
const DB_KEY = 'delicias_campeche_db_v4';

const defaultData = {
    users: [
        { id: 1, name: "Admin Principal", email: "admin@correo.com", password: "admin", role: "admin" },
        { id: 2, name: "Empleado de Cocina", email: "emp@correo.com", password: "123", role: "employee" },
        { id: 3, name: "Cliente Prueba", email: "test@correo.com", password: "123", role: "client" }
    ],
    products: [
        { id: 1, name: "Café Americano", category: "Bebidas", desc: "Grano tostado de altura.", price: 35.00, stock: 50, img: "https://images.unsplash.com/photo-1541167760496-162955ed8a9f?w=500" },
        { id: 2, name: "Pastel Tres Leches", category: "Pasteles", desc: "Clásico bañado en vainilla.", price: 450.00, stock: 5, img: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?w=500" },
        { id: 3, name: "Galletas Chispas", category: "Galletas", desc: "Cacao puro 70%.", price: 25.00, stock: 20, img: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=500" },
        { id: 4, name: "Concha de Vainilla", category: "Pan Dulce", desc: "Masa madre cubierta de azúcar.", price: 18.00, stock: 0, img: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500" },
        { id: 8, name: "Frappé Moka", category: "Bebidas", desc: "Refrescante mezcla de café y chocolate.", price: 65.00, stock: 15, img: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=500" },
        { id: 9, name: "Trufas de Cacao", category: "Chocolates", desc: "Ganache semi-amargo al 70%.", price: 85.00, stock: 20, img: "https://images.unsplash.com/photo-1548842603-4f9e1fc2c823?w=500" }
    ],
    reviews: [
        { id: 1, productId: 2, productName: "Pastel Tres Leches", user: "Mariana P.", stars: 5, text: "El mejor pastel que he probado. Super fresco.", date: "Hace 2 días", response: null },
        { id: 2, productId: 1, productName: "Café Americano", user: "Roberto D.", stars: 2, text: "Llegó un poco frío, el pan muy bueno pero la logística mala.", date: "Hace 1 semana", response: "Sentimos el inconveniente Roberto, trabajaremos con los repartidores para mejorar esto." },
        { id: 3, productId: 4, productName: "Concha de Vainilla", user: "Cliente Prueba", stars: 5, text: "Súper suavecitas, volveré a comprar.", date: "Hace 1 mes", response: null },
        { id: 4, productId: 3, productName: "Galletas Chispas", user: "Miguel A.", stars: 4, text: "Muy buenas pero algo caras para mi gusto.", date: "Hace 3 semanas", response: null },
        { id: 5, productId: 8, productName: "Frappé Moka", user: "Laura Mendoza", stars: 5, text: "Delicioso, lo pido cada viernes.", date: "Hace 2 semanas", response: null },
        { id: 6, productId: 2, productName: "Pastel Tres Leches", user: "Valeria S.", stars: 1, text: "El pan estaba algo reseco esta vez, decepción total.", date: "Hace 1 mes", response: null }
    ]
};

window.DB = {
    init: function() {
        if (!localStorage.getItem(DB_KEY)) {
            localStorage.setItem(DB_KEY, JSON.stringify(defaultData));
        }
    },
    getData: function() {
        return JSON.parse(localStorage.getItem(DB_KEY));
    },
    saveData: function(data) {
        localStorage.setItem(DB_KEY, JSON.stringify(data));
        // Disparar evento para que la misma pestaña sepa que hubo un cambio
        window.dispatchEvent(new Event('local_db_update'));
    },
    
    // MÉTODOS DE PRODUCTOS
    getProducts: () => DB.getData().products,
    updateStock: (id, change) => {
        let data = DB.getData();
        let p = data.products.find(x => x.id === id);
        if (p && p.stock + change >= 0) {
            p.stock += change;
            DB.saveData(data);
            return true;
        }
        return false;
    },
    addProduct: (prod) => { let d = DB.getData(); d.products.push(prod); DB.saveData(d); },
    deleteProduct: (id) => { let d = DB.getData(); d.products = d.products.filter(x => x.id !== id); DB.saveData(d); },

    // MÉTODOS DE USUARIOS
    getUsers: () => DB.getData().users,
    addUser: (user) => { let d = DB.getData(); d.users.push(user); DB.saveData(d); },
    deleteUser: (id) => { let d = DB.getData(); d.users = d.users.filter(x => x.id !== id); DB.saveData(d); },

    // MÉTODOS DE RESEÑAS
    getReviews: () => DB.getData().reviews,
    addReview: (rev) => { let d = DB.getData(); d.reviews.unshift(rev); DB.saveData(d); },
    updateReviewResponse: (id, resp) => { let d = DB.getData(); let r = d.reviews.find(x => x.id === id); if(r){ r.response = resp; DB.saveData(d); } },
    deleteReview: (id) => { let d = DB.getData(); d.reviews = d.reviews.filter(x => x.id !== id); DB.saveData(d); }
};

// Inicializar la BD al cargar este archivo
DB.init();