// Servidor para procesar pagos de Mercado Pago - Delicias de Campeche
// Ejecutar con: node server.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const { MercadoPagoConfig, Preference } = require('mercadopago');

const app = express();
const port = process.env.PORT || 3000;

// Habilitar CORS para que el frontend pueda comunicarse con el servidor
app.use(cors());
app.use(express.json());

// Servir archivos estáticos (HTML, CSS, JS, imágenes, etc.)
app.use(express.static(path.join(__dirname)));

// Ruta de prueba
app.get('/test', (req, res) => {
    res.json({ status: 'OK', message: 'Servidor funcionando correctamente en puerto 8000' });
});

const ACCESS_TOKEN = process.env.ACCESS_TOKEN || 'APP_USR-4668293017905083-041219-a1ce7bf520d0e472ad5b82045d248055-3330256811';

const client = new MercadoPagoConfig({ 
    accessToken: ACCESS_TOKEN.trim() 
});

// Ruta para crear la preferencia de pago
app.post('/crear-preferencia', async (req, res) => {
    try {
        const { items } = req.body;

        if (!items || items.length === 0) {
            return res.status(400).json({ error: "Carrito vacío" });
        }

        // Detectar el origen de la petición (ej. http://127.0.0.1:5500 o localhost:8000)
        const origin = req.headers.origin || "http://localhost:8000";

        // Estructura de la preferencia según la SDK v2
        const body = {
            items: items.map(item => ({
                title: String(item.title).substring(0, 250),
                quantity: parseInt(item.quantity),
                unit_price: parseFloat(item.unit_price),
                currency_id: 'MXN'
            })),
            back_urls: {
            success: `${origin}/index.html?status=success`,
            failure: `${origin}/index.html?status=failure`,
            pending: `${origin}/index.html?status=pending`,
        },
            auto_return: "approved", // <--- VITAL: Regresa automáticamente al cliente a tu tienda si el pago es exitoso
            statement_descriptor: "DELICIAS CAMP",
            external_reference: "dc_" + Date.now(),
        };

        const preference = new Preference(client);
        const result = await preference.create({ body });

        console.log("✅ Preferencia generada con éxito. ID:", result.id);
        res.json({ id: result.id });
        
    } catch (error) {
        console.error("\n❌ ERROR DETECTADO EN MERCADO PAGO:");
        console.error(error);
        res.status(error.status || 500).json({ 
            error: "Error de Mercado Pago", 
            message: error.message || "No se pudo crear la preferencia"
        });
    }
});

app.listen(port, () => {
    console.log("===============================================");
    console.log(`🚀 Servidor Delicias de Campeche en Puerto ${port}`);
    console.log(`🔑 Token configurado: ${ACCESS_TOKEN ? ACCESS_TOKEN.substring(0, 15) + '...' : 'No configurado'}`);
    console.log("===============================================");
});